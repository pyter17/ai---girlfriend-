
'use client';
import { useState, useRef } from 'react';

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const endRef = useRef(null);

  async function send() {
    if (!input.trim()) return;
    const userMsg = { from: 'user', text: input };
    setMessages((m) => [...m, userMsg]);
    setInput('');

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input }),
    });
    const data = await res.json();
    const aiMsg = { from: 'ai', text: data.reply };
    setMessages((m) => [...m, aiMsg]);
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }

  return (
    <div className="flex flex-col h-screen p-4">
      <div className="flex-1 overflow-y-auto space-y-2">
        {messages.map((m, i) => (
          <p key={i} className={m.from === 'user' ? 'text-right' : 'text-left'}>
            <span
              className={
                m.from === 'user'
                  ? 'inline-block bg-blue-500 text-white rounded-xl px-3 py-2'
                  : 'inline-block bg-gray-200 rounded-xl px-3 py-2'
              }>
              {m.text}
            </span>
          </p>
        ))}
        <div ref={endRef} />
      </div>

      <div className="mt-4 flex">
        <input
          className="flex-1 border rounded-l-xl px-3 py-2 focus:outline-none"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Scrivi qualcosa…"
          onKeyDown={(e) => e.key === 'Enter' && send()}
        />
        <button
          onClick={send}
          className="bg-blue-500 text-white px-4 rounded-r-xl">
          ➤
        </button>
      </div>
    </div>
  );
}
