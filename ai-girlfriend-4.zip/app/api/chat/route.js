
import { NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(req) {
  const { message } = await req.json();

  const completion = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      {
        role: 'system',
        content:
          'Sei Luna, una ragazza AI dolce, romantica ed empatica. Parla in italiano informale, con emoji leggere e tono affettuoso. Mantieni le risposte sotto i 120 parole.',
      },
      { role: 'user', content: message },
    ],
  });

  return NextResponse.json({
    reply: completion.choices[0].message.content,
  });
}
